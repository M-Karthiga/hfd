export interface FileData {
  file: File;
  previewUrl: string;
  type: 'image' | 'video' | 'audio';
  base64: string;
  mimeType: string;
}

export enum SeverityLevel {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High',
  CRITICAL = 'Critical'
}

export interface AuthenticityCheck {
  isAuthentic: boolean;
  confidence: number;
  reasoning: string;
  verdict: 'REAL_EVENT' | 'AI_GENERATED' | 'STAGED' | 'UNCERTAIN';
}

export interface EmergencyDetails {
  severity: SeverityLevel;
  estimatedTimeWindow: string;
  casualtyEstimate: number | string;
  cause: string;
  situationalSummary: string[];
}

export interface ResourceAssessment {
  vehiclesPresent: string[];
  vehiclesLacking: string[];
  immediateNeeds: string[];
}

export interface AnalysisResult {
  authenticity: AuthenticityCheck;
  emergency: EmergencyDetails;
  resources: ResourceAssessment;
}

export interface LoadingState {
  status: 'idle' | 'uploading' | 'screening' | 'analyzing' | 'complete' | 'error';
  message?: string;
}