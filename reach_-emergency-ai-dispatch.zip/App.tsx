import React, { useState } from 'react';
import { Header } from './components/Header';
import { FileUpload } from './components/FileUpload';
import { AnalysisDashboard } from './components/AnalysisDashboard';
import { analyzeMedia } from './services/geminiService';
import { FileData, AnalysisResult, LoadingState } from './types';
import { RefreshCw } from 'lucide-react';

const App: React.FC = () => {
  const [fileData, setFileData] = useState<FileData | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState<LoadingState>({ status: 'idle' });

  const handleFileSelect = async (data: FileData) => {
    setFileData(data);
    setAnalysisResult(null);
    setLoading({ status: 'screening', message: 'Screening for authenticity...' });

    try {
      // Small artificial delay to show state changes for UX
      setTimeout(async () => {
        setLoading({ status: 'analyzing', message: 'Analyzing emergency vectors...' });
        
        try {
          const result = await analyzeMedia(data);
          setAnalysisResult(result);
          setLoading({ status: 'complete' });
        } catch (error) {
          console.error(error);
          setLoading({ status: 'error', message: 'Analysis failed. Please try again.' });
        }
      }, 1500);
      
    } catch (error) {
      setLoading({ status: 'error', message: 'Failed to process file.' });
    }
  };

  const handleReset = () => {
    setFileData(null);
    setAnalysisResult(null);
    setLoading({ status: 'idle' });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-blue-500/30">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* Intro / Empty State */}
        {!fileData && (
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold tracking-tight text-white mb-4">Emergency Intelligence Dashboard</h2>
              <p className="text-lg text-slate-400">
                Upload surveillance footage, bystander video, or audio recordings. 
                REACH will analyze for authenticity, assess severity, and calculate immediate resource requirements.
              </p>
            </div>
            <FileUpload onFileSelect={handleFileSelect} isProcessing={loading.status !== 'idle'} />
          </div>
        )}

        {/* Loading / Error State */}
        {(loading.status !== 'idle' && loading.status !== 'complete') && (
           <div className="max-w-4xl mx-auto">
              <AnalysisDashboard 
                result={null} 
                fileData={fileData} 
                isLoading={true} 
                loadingMessage={loading.message} 
              />
           </div>
        )}

        {/* Results */}
        {loading.status === 'complete' && analysisResult && (
          <>
            <div className="flex justify-end">
              <button 
                onClick={handleReset}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-400 hover:text-white bg-slate-900 border border-slate-700 rounded-lg hover:bg-slate-800 transition-colors"
              >
                <RefreshCw size={14} /> NEW ANALYSIS
              </button>
            </div>
            <AnalysisDashboard 
              result={analysisResult} 
              fileData={fileData} 
              isLoading={false} 
            />
          </>
        )}

        {/* Error Display */}
        {loading.status === 'error' && (
          <div className="max-w-lg mx-auto mt-10 p-6 bg-red-950/30 border border-red-900/50 rounded-xl text-center">
            <h3 className="text-red-400 font-bold mb-2">System Error</h3>
            <p className="text-red-200/70 mb-4">{loading.message}</p>
            <button 
              onClick={handleReset}
              className="px-4 py-2 bg-red-900/50 hover:bg-red-800/50 text-red-100 rounded transition-colors"
            >
              Reset System
            </button>
          </div>
        )}

      </main>
    </div>
  );
};

export default App;