import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AnalysisResult, SeverityLevel, FileData } from "../types";

// Define the schema for the structured JSON output
const analysisSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    authenticity: {
      type: Type.OBJECT,
      properties: {
        isAuthentic: { type: Type.BOOLEAN, description: "True if the media appears to be a real-world recording, False if AI generated, from a video game, or staged." },
        confidence: { type: Type.NUMBER, description: "Confidence score between 0 and 100." },
        verdict: { type: Type.STRING, enum: ['REAL_EVENT', 'AI_GENERATED', 'STAGED', 'UNCERTAIN'] },
        reasoning: { type: Type.STRING, description: "Brief explanation of why the media is considered real or fake." }
      },
      required: ["isAuthentic", "confidence", "verdict", "reasoning"]
    },
    emergency: {
      type: Type.OBJECT,
      properties: {
        severity: { type: Type.STRING, enum: [SeverityLevel.LOW, SeverityLevel.MEDIUM, SeverityLevel.HIGH, SeverityLevel.CRITICAL] },
        estimatedTimeWindow: { type: Type.STRING, description: "Recommended response time based on visual severity (e.g., 'Immediate', 'Within 5 mins', 'Within 1 hour')." },
        casualtyEstimate: { type: Type.STRING, description: "Estimated number of people injured (e.g., '1-3', '10+', '0', 'None visible'). Must be numerical where possible." },
        cause: { type: Type.STRING, description: "The likely cause of the incident." },
        situationalSummary: { 
          type: Type.ARRAY, 
          items: { type: Type.STRING },
          description: "A list of 3-5 concise, high-value observations for the dispatcher." 
        }
      },
      required: ["severity", "estimatedTimeWindow", "casualtyEstimate", "cause", "situationalSummary"]
    },
    resources: {
      type: Type.OBJECT,
      properties: {
        vehiclesPresent: { 
          type: Type.ARRAY, 
          items: { type: Type.STRING },
          description: "List of emergency vehicles already visible/audible in the media."
        },
        vehiclesLacking: { 
          type: Type.ARRAY, 
          items: { type: Type.STRING },
          description: "List of vehicles that are missing but likely needed."
        },
        immediateNeeds: { 
          type: Type.ARRAY, 
          items: { type: Type.STRING },
          description: "Specific equipment or personnel needed immediately."
        }
      },
      required: ["vehiclesPresent", "vehiclesLacking", "immediateNeeds"]
    }
  },
  required: ["authenticity", "emergency", "resources"]
};

export const analyzeMedia = async (fileData: FileData): Promise<AnalysisResult> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found in environment variables.");
  }

  const ai = new GoogleGenAI({ apiKey });

  const modelName = 'gemini-2.5-flash';

  const promptText = `
    You are an expert Emergency Response Dispatcher AI (REACH).
    
    Your task is to analyze the provided media (Image, Video, or Audio) of a potential emergency situation.
    
    1. **SCREENING (CRITICAL)**: 
       - Analyze the media for signs of being AI-generated, from a video game, or a computer rendering. Look for artifacts, unnatural lighting, or 'deepfake' signatures.
       - **IF FAKE/AI/GAME**: Set 'isAuthentic' to false. Fill the 'emergency' and 'resources' sections with "N/A" or empty values. **Do NOT** perform detailed emergency analysis on fake images.
    
    2. **EMERGENCY ANALYSIS (Only if Authentic)**:
       - **Casualties**: Provide a **NUMERICAL RANGE** (e.g., "1-2", "5-10", "0", "Unknown"). Do NOT use vague terms like "some", "few", or "several".
       - **Time Window**: Analyze urgency dynamically based on the visual threat. Do NOT default to generic times. 
         - Life-threatening (Fire, Shooting, Heavy Bleeding) -> "Immediate"
         - Serious Injury -> "< 10 mins"
         - Property only -> "Standard"
       - **Summary**: Provide strictly **noteworthy key details** in point-wise format. Focus on what a dispatcher needs to tell the response team (e.g., "Structural collapse imminent", "Hazmat spill spreading").

    3. **RESOURCE ASSESSMENT**: Identify specific vehicles/gear needed.

    Provide the output strictly in the requested JSON format.
  `;

  const partData = {
    inlineData: {
      mimeType: fileData.mimeType,
      data: fileData.base64
    }
  };

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [partData, { text: promptText }]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        systemInstruction: "You are a specialized 911 dispatch analysis bot. Analyze inputs for operational intelligence. Be strict about authenticity.",
        temperature: 0.2
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response received from AI model.");
    }

    const result = JSON.parse(text) as AnalysisResult;
    return result;

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};