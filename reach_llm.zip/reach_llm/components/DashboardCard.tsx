import React from 'react';

interface DashboardCardProps {
  title: string;
  children: React.ReactNode;
  icon?: React.ReactNode;
  className?: string;
  variant?: 'default' | 'danger' | 'warning' | 'success';
}

export const DashboardCard: React.FC<DashboardCardProps> = ({ 
  title, 
  children, 
  icon, 
  className = '',
  variant = 'default'
}) => {
  
  const borderColors = {
    default: 'border-slate-800',
    danger: 'border-red-900/50',
    warning: 'border-orange-900/50',
    success: 'border-emerald-900/50',
  };

  const bgColors = {
    default: 'bg-slate-900/50',
    danger: 'bg-red-950/20',
    warning: 'bg-orange-950/20',
    success: 'bg-emerald-950/20',
  };

  return (
    <div className={`rounded-xl border ${borderColors[variant]} ${bgColors[variant]} backdrop-blur-sm overflow-hidden flex flex-col ${className}`}>
      <div className="px-5 py-4 border-b border-slate-800/50 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          {icon}
          {title}
        </h3>
      </div>
      <div className="p-5 flex-1">
        {children}
      </div>
    </div>
  );
};