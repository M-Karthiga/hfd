import React from 'react';
import { AnalysisResult, FileData, SeverityLevel } from '../types';
import { DashboardCard } from './DashboardCard';
import { 
  AlertTriangle, 
  Clock, 
  Users, 
  Ambulance, 
  CheckCircle2, 
  XCircle, 
  AlertOctagon,
  Search,
  Siren,
  Stethoscope,
  Truck,
  Ban
} from 'lucide-react';

interface AnalysisDashboardProps {
  result: AnalysisResult | null;
  fileData: FileData | null;
  isLoading: boolean;
  loadingMessage?: string;
}

export const AnalysisDashboard: React.FC<AnalysisDashboardProps> = ({ 
  result, 
  fileData, 
  isLoading,
  loadingMessage 
}) => {

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-96 space-y-6">
        <div className="relative w-24 h-24">
          <div className="absolute inset-0 border-t-4 border-blue-500 rounded-full animate-spin"></div>
          <div className="absolute inset-2 border-b-4 border-emerald-500 rounded-full animate-spin reverse"></div>
          <Siren className="absolute inset-0 m-auto text-slate-500 animate-pulse" />
        </div>
        <div className="text-center space-y-2">
          <h2 className="text-xl font-mono text-slate-200 animate-pulse">{loadingMessage || 'INITIALIZING SCAN...'}</h2>
          <p className="text-slate-500 text-sm">Processing neural patterns...</p>
        </div>
      </div>
    );
  }

  if (!result || !fileData) return null;

  const isFake = !result.authenticity.isAuthentic;

  const getSeverityColor = (level: SeverityLevel) => {
    switch (level) {
      case SeverityLevel.CRITICAL: return 'text-red-500 bg-red-500/10 border-red-500/50';
      case SeverityLevel.HIGH: return 'text-orange-500 bg-orange-500/10 border-orange-500/50';
      case SeverityLevel.MEDIUM: return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/50';
      case SeverityLevel.LOW: return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/50';
      default: return 'text-slate-500';
    }
  };

  const getAuthenticityColor = (verdict: string) => {
    switch (verdict) {
      case 'REAL_EVENT': return 'text-emerald-400';
      case 'AI_GENERATED': return 'text-purple-400';
      case 'STAGED': return 'text-yellow-400';
      default: return 'text-slate-400';
    }
  };

  // Render for Fake/AI Detected - Minimal View
  if (isFake) {
    return (
       <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700 max-w-4xl mx-auto">
          {/* Header Warning */}
          <div className="rounded-lg bg-red-950/40 border border-red-500/50 p-4 flex items-center gap-4 text-red-200">
             <Ban className="h-8 w-8 text-red-500" />
             <div>
                <h3 className="text-lg font-bold font-mono uppercase tracking-wide">Analysis Aborted</h3>
                <p className="text-sm opacity-80">Source material flagged as inauthentic. Dispatch protocols suspended.</p>
             </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
             {/* Media Preview */}
             <div className="rounded-xl overflow-hidden border border-slate-800 bg-black relative h-80">
                {fileData.type === 'video' && (
                  <video src={fileData.previewUrl} controls className="w-full h-full object-contain" />
                )}
                {fileData.type === 'image' && (
                  <img src={fileData.previewUrl} alt="Incident" className="w-full h-full object-contain" />
                )}
                {fileData.type === 'audio' && (
                  <div className="w-full h-full flex items-center justify-center bg-slate-900">
                      <audio src={fileData.previewUrl} controls className="w-4/5" />
                  </div>
                )}
                <div className="absolute top-0 inset-x-0 bg-red-600 text-white text-center py-1 text-xs font-mono font-bold tracking-widest uppercase shadow-lg">
                    SYNTHETIC / STAGED CONTENT DETECTED
                </div>
             </div>

             {/* Authenticity Details Only */}
             <DashboardCard 
                title="Source Integrity Report" 
                icon={<Search size={18} className="text-red-400" />}
                className="h-full"
                variant="danger"
              >
                <div className="flex flex-col h-full justify-center space-y-6">
                  <div className="text-center">
                    <div className={`text-3xl font-bold font-mono tracking-tight mb-2 ${getAuthenticityColor(result.authenticity.verdict)}`}>
                      {result.authenticity.verdict.replace('_', ' ')}
                    </div>
                    <div className="inline-block px-3 py-1 rounded-full bg-slate-900 border border-slate-700 text-xs font-mono text-slate-400">
                      CONFIDENCE: {result.authenticity.confidence}%
                    </div>
                  </div>
                  
                  <div className="bg-black/20 p-4 rounded-lg border border-red-900/30 text-slate-300">
                    <h4 className="text-xs text-red-400 uppercase font-bold mb-2">Detection Reasoning</h4>
                    <p className="leading-relaxed">{result.authenticity.reasoning}</p>
                  </div>
                </div>
             </DashboardCard>
          </div>
       </div>
    );
  }

  // Render for Real Events - Full Dashboard
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Media Preview */}
        <div className="lg:col-span-1 rounded-xl overflow-hidden border border-slate-800 bg-black relative group">
          {fileData.type === 'video' && (
            <video src={fileData.previewUrl} controls className="w-full h-full object-cover max-h-[300px]" />
          )}
          {fileData.type === 'image' && (
            <img src={fileData.previewUrl} alt="Incident" className="w-full h-full object-cover max-h-[300px]" />
          )}
          {fileData.type === 'audio' && (
             <div className="w-full h-[300px] flex items-center justify-center bg-slate-900">
                <audio src={fileData.previewUrl} controls className="w-4/5" />
             </div>
          )}
          <div className="absolute top-2 right-2 px-2 py-1 bg-black/70 backdrop-blur rounded text-xs font-mono border border-slate-700">
            SOURCE_MEDIA
          </div>
        </div>

        {/* High Level Stats */}
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
           {/* Authenticity Card */}
           <DashboardCard 
              title="Source Integrity Scan" 
              icon={<Search size={18} className="text-blue-400" />}
            >
              <div className="flex flex-col h-full justify-between">
                <div className="flex items-center justify-between mb-4">
                  <div className={`text-2xl font-bold font-mono tracking-tight ${getAuthenticityColor(result.authenticity.verdict)}`}>
                    {result.authenticity.verdict.replace('_', ' ')}
                  </div>
                  <div className="radial-progress text-xs font-mono text-slate-400">
                    {result.authenticity.confidence}% CONFIDENCE
                  </div>
                </div>
                
                <div className="bg-slate-950/50 p-3 rounded-lg border border-slate-800/50 text-xs text-slate-400">
                  <p className="line-clamp-3">{result.authenticity.reasoning}</p>
                </div>
                
                <div className="mt-4 flex items-center gap-2 text-xs text-slate-500 uppercase">
                   <CheckCircle2 size={16} className="text-emerald-500" />
                   <span>Verification Status: PASSED</span>
                </div>
              </div>
           </DashboardCard>

           {/* Severity Card */}
           <DashboardCard 
              title="Threat Assessment" 
              icon={<AlertTriangle size={18} className="text-warning" />}
              variant={result.emergency.severity === SeverityLevel.CRITICAL ? 'danger' : 'default'}
           >
              <div className="flex flex-col h-full justify-center items-center text-center space-y-2">
                 <div className={`text-sm font-mono uppercase tracking-widest text-slate-400`}>Severity Level</div>
                 <div className={`text-4xl font-black tracking-tighter px-6 py-2 rounded-lg border-2 ${getSeverityColor(result.emergency.severity)}`}>
                    {result.emergency.severity}
                 </div>
                 <p className="text-xs text-slate-400 mt-2">Protocol: {result.emergency.severity === 'Critical' ? 'IMMEDIATE DISPATCH' : 'STANDARD RESPONSE'}</p>
              </div>
           </DashboardCard>
        </div>
      </div>

      {/* Incident Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <DashboardCard title="Casualties" icon={<Users size={18} className="text-red-400" />}>
          <div className="flex items-center gap-4">
             <div className="p-3 bg-red-900/20 rounded-full">
                <Stethoscope className="text-red-500 w-8 h-8" />
             </div>
             <div>
               <div className="text-2xl font-bold text-white">{result.emergency.casualtyEstimate}</div>
               <div className="text-xs text-slate-400 uppercase">Estimated Injured</div>
             </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Response Window" icon={<Clock size={18} className="text-orange-400" />}>
           <div className="flex items-center gap-4">
             <div className="p-3 bg-orange-900/20 rounded-full">
                <Clock className="text-orange-500 w-8 h-8" />
             </div>
             <div>
               <div className="text-xl font-bold text-white leading-tight">{result.emergency.estimatedTimeWindow}</div>
               <div className="text-xs text-slate-400 uppercase">Recommended ETA</div>
             </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Incident Cause" icon={<AlertOctagon size={18} className="text-yellow-400" />}>
           <div className="h-full flex items-center">
              <p className="text-lg text-slate-200 font-medium leading-snug">
                {result.emergency.cause}
              </p>
           </div>
        </DashboardCard>
      </div>

      {/* Situational Summary - Updated to List */}
      <DashboardCard title="Dispatcher Key Observations" className="border-blue-900/30 bg-blue-950/10">
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3">
          {result.emergency.situationalSummary.map((point, idx) => (
             <li key={idx} className="flex items-start gap-3 text-blue-100/90 font-mono text-sm leading-relaxed">
               <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-blue-400 shrink-0"></span>
               {point}
            </li>
          ))}
        </ul>
      </DashboardCard>

      {/* Resource Allocation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <DashboardCard title="Resources Present" icon={<CheckCircle2 className="text-emerald-400" size={18}/>}>
           {result.resources.vehiclesPresent.length > 0 ? (
             <ul className="space-y-2">
               {result.resources.vehiclesPresent.map((v, i) => (
                 <li key={i} className="flex items-center gap-3 p-2 bg-slate-800/50 rounded border border-slate-700">
                    <Ambulance size={16} className="text-emerald-500" />
                    <span className="text-sm text-slate-200">{v}</span>
                 </li>
               ))}
             </ul>
           ) : (
             <div className="text-slate-500 italic p-2">No emergency vehicles detected on scene.</div>
           )}
        </DashboardCard>

        <DashboardCard title="Critical Needs / Missing" icon={<XCircle className="text-red-400" size={18}/>} variant="danger">
           <div className="space-y-4">
              {result.resources.vehiclesLacking.length > 0 && (
                 <div>
                    <h4 className="text-xs font-bold text-red-400 uppercase mb-2">Vehicles Needed</h4>
                    <div className="flex flex-wrap gap-2">
                      {result.resources.vehiclesLacking.map((v, i) => (
                        <span key={i} className="px-2 py-1 bg-red-500/10 border border-red-500/30 rounded text-red-200 text-sm flex items-center gap-2">
                           <Truck size={12}/> {v}
                        </span>
                      ))}
                    </div>
                 </div>
              )}
              
              {result.resources.immediateNeeds.length > 0 && (
                 <div>
                    <h4 className="text-xs font-bold text-orange-400 uppercase mb-2">Specialized Equipment</h4>
                    <ul className="space-y-1">
                      {result.resources.immediateNeeds.map((item, i) => (
                         <li key={i} className="text-sm text-slate-300 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                            {item}
                         </li>
                      ))}
                    </ul>
                 </div>
              )}
           </div>
        </DashboardCard>
      </div>
    </div>
  );
};