import React, { useRef, useState } from 'react';
import { UploadCloud, FileVideo, FileAudio, FileImage, AlertCircle } from 'lucide-react';
import { readFileToBase64, getFileType, formatFileSize } from '../utils/fileUtils';
import { FileData } from '../types';

interface FileUploadProps {
  onFileSelect: (data: FileData) => void;
  isProcessing: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, isProcessing }) => {
  const [dragActive, setDragActive] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFile = async (file: File) => {
    if (!file) return;

    // Basic validation
    if (file.size > 20 * 1024 * 1024) { // 20MB limit for demo
        alert("File too large. Please upload files under 20MB.");
        return;
    }

    try {
      const base64 = await readFileToBase64(file);
      const type = getFileType(file);
      
      const fileData: FileData = {
        file,
        previewUrl: URL.createObjectURL(file),
        type,
        base64,
        mimeType: file.type
      };
      
      onFileSelect(fileData);
    } catch (err) {
      console.error("Error reading file", err);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  return (
    <div 
      className={`relative rounded-xl border-2 border-dashed transition-all duration-300 ease-in-out h-64 flex flex-col items-center justify-center cursor-pointer overflow-hidden group
        ${dragActive ? 'border-blue-500 bg-blue-500/10' : 'border-slate-700 bg-slate-900/30 hover:border-slate-500 hover:bg-slate-800/50'}
        ${isProcessing ? 'opacity-50 pointer-events-none' : ''}
      `}
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
    >
      <input 
        ref={inputRef}
        type="file" 
        className="hidden" 
        onChange={handleChange}
        accept="image/*,video/*,audio/*"
      />
      
      <div className="z-10 flex flex-col items-center text-center p-6 space-y-4">
        <div className={`p-4 rounded-full bg-slate-800 transition-transform duration-300 group-hover:scale-110 ${dragActive ? 'bg-blue-600' : ''}`}>
          <UploadCloud className="w-8 h-8 text-slate-200" />
        </div>
        <div className="space-y-1">
          <p className="text-lg font-medium text-slate-200">
            Drop emergency media here
          </p>
          <p className="text-sm text-slate-400">
            Supports MP4, JPG, PNG, MP3, WAV
          </p>
        </div>
        <div className="flex gap-4 text-xs text-slate-500 font-mono pt-2">
          <span className="flex items-center gap-1"><FileVideo size={14} /> VIDEO</span>
          <span className="flex items-center gap-1"><FileImage size={14} /> IMAGE</span>
          <span className="flex items-center gap-1"><FileAudio size={14} /> AUDIO</span>
        </div>
      </div>

      {/* Grid Pattern Background */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
           style={{
             backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
             backgroundSize: '20px 20px'
           }} 
      />
    </div>
  );
};